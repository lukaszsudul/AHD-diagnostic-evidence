# V41 NVP ACK shadow-monitor R2 measurement package

This package preserves the single authorized observer-only R2 hardware
measurement. It contains the sealed diagnostic identity, one-shot programming
and post-reboot JTAG evidence, raw and decoded traces, bounded existing
telemetry, PCIe/XDMA/kernel health, correlation reports and operation ledger.

```text
BUILD_TYPE=EPHEMERAL_DIAGNOSTIC_OBSERVER_ONLY_R2
BASE_FUNCTIONAL_COMMIT=fd32fcb65be3f1a59c569874195d1faeaf7d27e9
OBSERVER_R2_PATCH_SHA256=78C2D4099A20F1A8C81D15CBE7E7AB15E7F041FBA9C03A07AE83593CCD2F0E51
R2_BIT_SHA256=FCAE29F83904F69487545400AB83756ADA9FFC99A78C0A387DD4604A130CD43A
R2_PRIMARY_CLASSIFICATION=REAL_DIGITAL_NACK_AT_CORRECT_ACK_PHASE_CONFIRMED
R2_FALSE_NACK_COUNT=0
R2_REAL_DIGITAL_NACK_COUNT=1
R2_INVALID_ACK_WINDOWS=0
TRACE_TELEMETRY_CORRELATION=PASS
RAW_ANALOG_MEASUREMENT_AVAILABLE=NO
AXIL_WRITES=0
C2H_TRANSFERS=0
H2C_TRANSFERS=0
PHASE3_RESUMED=NO
```

The R2 observer does not identify the sole physical cause. It proves that, for
the reproduced event, SDA remained digitally HIGH at the early, midpoint and
late samples of a valid SCL-HIGH ACK interval while the master had released
both lines.
