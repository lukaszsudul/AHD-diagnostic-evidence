# V41 NVP trace diagnostic measurement package

This package contains the single authorized observer-only hardware
measurement. It references the separately sealed diagnostic build package by
its package SHA-256 and includes the exact runtime build identity, schema,
program/reboot gates, raw 32 KiB trace, full decoded data, focused ACK window,
unchanged-register telemetry, driver/PCIe/kernel health evidence, scientific
correlation, and operation ledger.

The diagnostic build package remains a separate artifact because it contains
the routed DCP, bitstream, complete build reports, and simulations. Its
identity is recorded in `00_IDENTITY`.

```text
MEASUREMENT_COUNT=1
TRACE_DUMP_COUNT=1
TRACE_SAMPLE_COUNT=4096
TRACE_OVERFLOW=0
TRACE_SHA256=6233244DED531F632B1DF54C477540EBC01088A21A7C4D6A3BC141829BA64477
PRIMARY_CLASSIFICATION=NO_DIGITAL_ACK_OBSERVED_AT_FPGA_INPUT_PATH_AT_DECISION
DIGITAL_ACK_LIKE_LOW_PRESENT_DURING_PRECEDING_SCL_HIGH=YES
TRACE_TELEMETRY_CORRELATION=PASS
AXIL_WRITES=0
C2H_TRANSFERS=0
H2C_TRANSFERS=0
```
