# Diagnostic reboot and trace-retrieval gate

The sealed observer-only image was programmed once on 2026-08-18. The
one-shot programming script found exactly one `xc7a35t`, verified IDCODE
`0362D093`, completed `program_hw_devices`, and reported EOS HIGH and DONE 1.

The required Ubuntu warm reboot changed the boot ID from
`4d1b92c2-b5be-4361-9e1c-546509bbb2df` to
`fbb23d86-fecd-40ed-8ac1-df3cbcf6185b`. After the reboot:

```text
SSH_AUTHENTICATED=YES
HOSTNAME=VCDE-DUT-1
HOST_IPV4=10.132.1.111
FPGA=xc7a35t
FPGA_IDCODE=0362D093
FPGA_DONE=1
PCIE_BDF=0000:01:00.0
PCIE_VID_DID=10ee:7011
PCIE_SUBSYSTEM=10ee:0007
PCIE_CLASS=058000
PCIE_LINK=Gen1_x1
BAR0=131072_BYTES
BAR1=65536_BYTES
XDMA_DRIVER_COMMIT=8721136e74a66500b02d16cb41922d966139cd46
XDMA_MODULE_SHA256=1AEF06244DF308FEE544A2662B73855C81BEB88BC929E7885D8D113E474B320A
XDMA_DRIVER_LOAD=PASS
EXPECTED_XDMA_NODES=PASS
```

The transferred dump tool matched its sealed local SHA-256
`A743BDE70951403E49A15BF0353DF9D0C0B021B27D8C7CF91198F88141B857F9`.
It opened the user endpoint read-only, validated the platform and diagnostic
identity, then read the complete trace exactly once.

```text
DIAG_MAGIC=0x4E565054
DIAG_SCHEMA_VERSION=0x00010000
DIAG_FLAGS=0x00000003
TRACE_STATUS=0x0000000E
TRACE_FROZEN=1
TRACE_FULL_PRETRIGGER_HISTORY=1
TRACE_OVERFLOW=0
TRACE_TRIGGER_REASON=FIRST_NACK
TRACE_TRIGGER_INDEX=3072
TRACE_SAMPLE_COUNT=4096
TRACE_SHA256=6233244DED531F632B1DF54C477540EBC01088A21A7C4D6A3BC141829BA64477
DIAGNOSTIC_AXIL_READS=8227
DIAGNOSTIC_AXIL_WRITES=0
```

The copied Windows files hash-identically to the Ubuntu originals. The kernel
health filter found only the expected unsigned out-of-tree XDMA module
verification/taint message. It found no AER error, completion timeout, XDMA
runtime failure, Oops, panic, hung task, or watchdog lockup attributable to the
measurement. The endpoint, driver, user node, and Gen1 x1 link remained present
after retrieval.

```text
DIAGNOSTIC_PROGRAM=PASS_EOS_HIGH_DONE_1
DIAGNOSTIC_WARM_REBOOT=PASS
DIAGNOSTIC_IDENTITY_GATE=PASS
TRACE_RETRIEVAL=PASS
TRACE_ARCHIVE_COPY_HASH_GATE=PASS
KERNEL_PCIE_XDMA_HEALTH=PASS
```
