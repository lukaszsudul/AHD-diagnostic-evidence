#!/usr/bin/env python3
"""Read-only dump and decoder for the ephemeral NVP/I2C trace image."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import socket
import stat
import struct
import subprocess
import sys


DIAG_BASE = 0x2000
TRACE_BASE = 0x3000
EXPECTED_MAGIC = 0x4E565054
EXPECTED_SCHEMA = 0x00010000
EXPECTED_FLAGS = 0x00000003
EXPECTED_HOSTNAME = "VCDE-DUT-1"
EXPECTED_IP = "10.132.1.111"
EXPECTED_BDF = "0000:01:00.0"
EXPECTED_BASE_COMMIT = "fd32fcb65be3f1a59c569874195d1faeaf7d27e9"
EXPECTED_DRIVER_COMMIT = "8721136e74a66500b02d16cb41922d966139cd46"
DRIVER_REPOSITORY = Path("/home/vcdeagent1/FPGA_AHD_HOST/dma_ip_drivers")


STATUS_OFFSETS = {
    "diag_magic": 0x00,
    "schema_version": 0x04,
    "diag_flags": 0x08,
    "trace_status": 0x0C,
    "trigger_reason": 0x10,
    "sample_clock_hz": 0x14,
    "sample_depth": 0x18,
    "sample_width_bits": 0x1C,
    "pre_trigger_count": 0x20,
    "post_trigger_count": 0x24,
    "trigger_index": 0x28,
    "final_write_index": 0x2C,
    "overflow": 0x30,
    "base_commit_w0": 0x34,
    "base_commit_w1": 0x38,
    "base_commit_w2": 0x3C,
    "base_commit_w3": 0x40,
    "base_commit_w4": 0x44,
    "patch_sha_w0": 0x48,
    "patch_sha_w1": 0x4C,
    "patch_sha_w2": 0x50,
    "patch_sha_w3": 0x54,
    "patch_sha_w4": 0x58,
    "patch_sha_w5": 0x5C,
    "patch_sha_w6": 0x60,
    "patch_sha_w7": 0x64,
    "first_error_valid": 0x68,
    "first_error_phase": 0x6C,
    "first_error_step": 0x70,
    "first_error_meta_bank": 0x74,
    "first_error_phys_bank": 0x78,
    "first_error_register": 0x7C,
    "first_error_value": 0x80,
    "valid_sample_count": 0x84,
    "physical_trigger_index": 0x88,
}


DECODE_COLUMNS = [
    "sample_index", "relative_cycles_from_trigger", "relative_time_ns",
    "sda_stage1", "sda_stage2", "sda_filtered",
    "scl_stage1", "scl_stage2", "scl_filtered",
    "sda_drive_low", "scl_drive_low", "ack_decision_strobe",
    "ack_value_used", "first_nack_event", "first_nack_latched",
    "nvp_reset", "vdd1_enable", "vdd3_enable", "init_active",
    "bit_index", "byte_phase", "fsm_state", "operation_index",
    "current_tx_byte", "init_done", "init_error", "first_error_code",
    "first_error_valid", "raw_hex",
]


def fail(message: str) -> None:
    raise RuntimeError(message)


def read_text(path: Path) -> str:
    return path.read_text(encoding="ascii").strip().lower()


def check_platform(device: Path) -> dict[str, object]:
    if socket.gethostname() != EXPECTED_HOSTNAME:
        fail(f"wrong host: {socket.gethostname()} != {EXPECTED_HOSTNAME}")
    ip_output = subprocess.run(
        ["ip", "-4", "-o", "addr", "show"], check=True,
        text=True, capture_output=True).stdout
    if EXPECTED_IP not in ip_output:
        fail(f"expected host IPv4 {EXPECTED_IP} not present")

    matches: list[Path] = []
    for entry in Path("/sys/bus/pci/devices").iterdir():
        try:
            if read_text(entry / "vendor") == "0x10ee" and \
               read_text(entry / "device") == "0x7011":
                matches.append(entry)
        except (FileNotFoundError, PermissionError):
            continue
    if len(matches) != 1:
        fail(f"expected exactly one 10ee:7011 endpoint, found {len(matches)}")
    endpoint = matches[0]
    if endpoint.name != EXPECTED_BDF:
        fail(f"wrong BDF: {endpoint.name} != {EXPECTED_BDF}")
    checks = {
        "subsystem_vendor": ("subsystem_vendor", "0x10ee"),
        "subsystem_device": ("subsystem_device", "0x0007"),
        "class": ("class", "0x058000"),
        "current_link_width": ("current_link_width", "1"),
    }
    observed: dict[str, object] = {"bdf": endpoint.name}
    for label, (filename, expected) in checks.items():
        actual = read_text(endpoint / filename)
        if actual != expected:
            fail(f"{label} mismatch: {actual} != {expected}")
        observed[label] = actual
    link_speed = (endpoint / "current_link_speed").read_text().strip()
    if not link_speed.startswith("2.5 GT/s"):
        fail(f"link is not Gen1: {link_speed}")
    observed["current_link_speed"] = link_speed

    resource_lines = (endpoint / "resource").read_text().splitlines()
    sizes = []
    for line in resource_lines[:2]:
        start_s, end_s, _flags_s = line.split()
        start, end = int(start_s, 16), int(end_s, 16)
        sizes.append(0 if start == 0 and end == 0 else end - start + 1)
    if sizes != [0x20000, 0x10000]:
        fail(f"BAR sizes mismatch: {sizes}")
    observed["bar0_bytes"], observed["bar1_bytes"] = sizes

    if not Path("/sys/module/xdma").is_dir():
        fail("xdma kernel module is not loaded")
    driver_commit = subprocess.run(
        ["git", "-C", str(DRIVER_REPOSITORY), "rev-parse", "HEAD"],
        check=True, text=True, capture_output=True).stdout.strip().lower()
    if driver_commit != EXPECTED_DRIVER_COMMIT:
        fail(f"XDMA driver commit mismatch: {driver_commit}")
    observed["driver_commit"] = driver_commit

    st = device.stat()
    if not stat.S_ISCHR(st.st_mode):
        fail(f"user endpoint is not a character device: {device}")
    observed["device"] = str(device)
    return observed


class ReadOnlyMmio:
    def __init__(self, device: Path) -> None:
        self.fd = os.open(device, os.O_RDONLY | os.O_CLOEXEC)
        self.read_count = 0

    def close(self) -> None:
        os.close(self.fd)

    def read32(self, offset: int) -> int:
        payload = os.pread(self.fd, 4, offset)
        if len(payload) != 4:
            fail(f"short AXI-Lite read at 0x{offset:05x}: {len(payload)}")
        self.read_count += 1
        return struct.unpack("<I", payload)[0]


def field(word: int, lsb: int, width: int = 1) -> int:
    return (word >> lsb) & ((1 << width) - 1)


def decode_sample(index: int, trigger_index: int, clock_hz: int,
                  word: int) -> dict[str, int | str]:
    relative = index - trigger_index
    return {
        "sample_index": index,
        "relative_cycles_from_trigger": relative,
        "relative_time_ns": relative * 1_000_000_000 // clock_hz,
        "sda_stage1": field(word, 0),
        "sda_stage2": field(word, 1),
        "sda_filtered": field(word, 2),
        "scl_stage1": field(word, 3),
        "scl_stage2": field(word, 4),
        "scl_filtered": field(word, 5),
        "sda_drive_low": field(word, 6),
        "scl_drive_low": field(word, 7),
        "ack_decision_strobe": field(word, 8),
        "ack_value_used": field(word, 9),
        "first_nack_event": field(word, 10),
        "first_nack_latched": field(word, 11),
        "nvp_reset": field(word, 12),
        "vdd1_enable": field(word, 13),
        "vdd3_enable": field(word, 14),
        "init_active": field(word, 15),
        "bit_index": field(word, 16, 4),
        "byte_phase": field(word, 20, 8),
        "fsm_state": field(word, 28, 8),
        "operation_index": field(word, 36, 8),
        "current_tx_byte": field(word, 44, 8),
        "init_done": field(word, 52),
        "init_error": field(word, 53),
        "first_error_code": field(word, 54, 8),
        "first_error_valid": field(word, 62),
        "raw_hex": f"0x{word:016X}",
    }


def write_csv(path: Path, rows: list[dict[str, object]], columns: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def classify(trigger_reason: int, trigger: dict[str, object],
             decoded: list[dict[str, object]]) -> tuple[str, list[str]]:
    secondary: list[str] = []
    if trigger_reason == 2:
        return "INTERMITTENT_NVP_FAILURE_NOT_REPRODUCED_IN_DIAGNOSTIC_BUILD", secondary
    if trigger_reason != 1 or int(trigger["first_nack_event"]) != 1:
        return "INCONCLUSIVE_DIGITAL_TRACE", secondary

    if any(int(row["scl_drive_low"]) == 0 and
           (int(row["scl_stage1"]) == 0 or int(row["scl_stage2"]) == 0 or
            int(row["scl_filtered"]) == 0)
           for row in decoded[max(0, int(trigger["sample_index"]) - 16):
                              int(trigger["sample_index"]) + 17]):
        secondary.append("SCL_RELEASE_OR_CLOCK_STRETCH_OBSERVATION_REQUIRES_FURTHER_ANALYSIS")

    if int(trigger["sda_drive_low"]) == 1:
        return "MASTER_DID_NOT_RELEASE_SDA_FOR_ACK", secondary
    if int(trigger["sda_filtered"]) == 0 and int(trigger["ack_value_used"]) == 0:
        return "FILTERED_ACK_LOW_BUT_FSM_LATCHED_NACK", secondary
    if (int(trigger["sda_stage1"]) == 0 or int(trigger["sda_stage2"]) == 0) and \
       int(trigger["sda_filtered"]) == 1:
        return "ACK_LOW_REACHED_EARLY_DIGITAL_STAGE_BUT_FILTERED_DECISION_MISSED", secondary
    if int(trigger["sda_stage1"]) == 1 and int(trigger["sda_stage2"]) == 1 and \
       int(trigger["sda_filtered"]) == 1:
        return "NO_DIGITAL_ACK_OBSERVED_AT_FPGA_INPUT_PATH", secondary
    return "INCONCLUSIVE_DIGITAL_TRACE", secondary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", type=Path, default=Path("/dev/xdma0_user"))
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--expected-patch-sha", required=True)
    parser.add_argument("--expected-base-commit", default=EXPECTED_BASE_COMMIT)
    args = parser.parse_args()

    expected_patch = args.expected_patch_sha.lower()
    expected_base = args.expected_base_commit.lower()
    if len(expected_patch) != 64 or any(c not in "0123456789abcdef" for c in expected_patch):
        fail("--expected-patch-sha must be 64 hexadecimal characters")
    if len(expected_base) != 40 or any(c not in "0123456789abcdef" for c in expected_base):
        fail("--expected-base-commit must be 40 hexadecimal characters")

    args.output_dir.mkdir(parents=True, exist_ok=False)
    platform = check_platform(args.device)
    mmio = ReadOnlyMmio(args.device)
    try:
        status = {name: mmio.read32(DIAG_BASE + offset)
                  for name, offset in STATUS_OFFSETS.items()}
        if status["diag_magic"] != EXPECTED_MAGIC:
            fail(f"diagnostic magic mismatch: 0x{status['diag_magic']:08X}")
        if status["schema_version"] != EXPECTED_SCHEMA:
            fail(f"unsupported schema: 0x{status['schema_version']:08X}")
        if status["diag_flags"] != EXPECTED_FLAGS:
            fail(f"diagnostic flags mismatch: 0x{status['diag_flags']:08X}")
        if not (status["trace_status"] & (1 << 2)):
            fail("trace is not frozen")
        if not (status["trace_status"] & (1 << 3)):
            fail("trace did not contain a full pre-trigger history")
        if status["trace_status"] & (1 << 4) or status["overflow"] != 0:
            fail("trace overflow is set")
        if status["trigger_reason"] not in (1, 2):
            fail(f"invalid trigger reason {status['trigger_reason']}")
        if status["sample_clock_hz"] != 62_500_000 or \
           status["sample_depth"] != 4096 or \
           status["sample_width_bits"] != 64 or \
           status["pre_trigger_count"] != 3072 or \
           status["post_trigger_count"] != 1024 or \
           status["trigger_index"] != 3072 or \
           status["valid_sample_count"] != 4096:
            fail("trace geometry does not match schema")

        runtime_base = "".join(
            f"{status[f'base_commit_w{i}']:08x}" for i in range(5))
        runtime_patch = "".join(
            f"{status[f'patch_sha_w{i}']:08x}" for i in range(8))
        if runtime_base != expected_base:
            fail(f"base commit mismatch: {runtime_base}")
        if runtime_patch != expected_patch:
            fail(f"patch SHA mismatch: {runtime_patch}")

        words: list[int] = []
        raw = bytearray()
        word_rows: list[dict[str, object]] = []
        decoded: list[dict[str, object]] = []
        for index in range(status["sample_depth"]):
            lower = mmio.read32(TRACE_BASE + index * 8)
            upper = mmio.read32(TRACE_BASE + index * 8 + 4)
            word = lower | (upper << 32)
            words.append(word)
            raw.extend(struct.pack("<Q", word))
            relative = index - status["trigger_index"]
            word_rows.append({
                "sample_index": index,
                "relative_cycles_from_trigger": relative,
                "relative_time_ns": relative * 1_000_000_000 // status["sample_clock_hz"],
                "lower_word": f"0x{lower:08X}",
                "upper_word": f"0x{upper:08X}",
                "sample_word": f"0x{word:016X}",
            })
            decoded.append(decode_sample(index, status["trigger_index"],
                                         status["sample_clock_hz"], word))

        raw_path = args.output_dir / "TRACE_RAW.bin"
        raw_path.write_bytes(raw)
        trace_sha = hashlib.sha256(raw).hexdigest().upper()
        (args.output_dir / "TRACE_SHA256.txt").write_text(
            f"{trace_sha}  TRACE_RAW.bin\n", encoding="ascii")
        write_csv(args.output_dir / "TRACE_WORDS.csv", word_rows,
                  list(word_rows[0].keys()))
        write_csv(args.output_dir / "TRACE_DECODED.csv", decoded, DECODE_COLUMNS)

        ack_indices = [int(row["sample_index"]) for row in decoded
                       if int(row["ack_decision_strobe"]) == 1]
        focused_indices: set[int] = set()
        for index in ack_indices:
            focused_indices.update(range(max(0, index - 16),
                                         min(len(decoded), index + 17)))
        focused = [decoded[index] for index in sorted(focused_indices)]
        write_csv(args.output_dir / "ACK_DECISION_FOCUSED.csv", focused,
                  DECODE_COLUMNS)

        trigger = decoded[status["trigger_index"]]
        first_nack_rows = [row for row in decoded if int(row["first_nack_event"]) == 1]
        if status["trigger_reason"] == 1:
            if len(first_nack_rows) != 1 or \
               int(first_nack_rows[0]["sample_index"]) != status["trigger_index"]:
                fail("first-NACK event does not match frozen trigger index")
        primary, secondary = classify(status["trigger_reason"], trigger, decoded)

        expected_phase = status["first_error_phase"] if status["first_error_phase"] in (1,2,3,4) else None
        correlation = "PASS" if expected_phase is not None and \
            int(trigger["byte_phase"]) == expected_phase and \
            int(trigger["operation_index"]) == status["first_error_step"] else "INCONCLUSIVE"
        if status["trigger_reason"] == 2 and status["first_error_valid"] == 0:
            correlation = "NOT_APPLICABLE_NO_NACK"

        status_payload = {
            "platform": platform,
            "status": {key: f"0x{value:08X}" for key, value in status.items()},
            "runtime_base_commit": runtime_base,
            "runtime_patch_sha256": runtime_patch,
            "mmio_reads": mmio.read_count,
            "mmio_writes": 0,
            "trace_sha256": trace_sha,
            "ack_decision_count": len(ack_indices),
            "primary_classification": primary,
            "secondary_observations": secondary,
            "trace_telemetry_correlation": correlation,
        }
        (args.output_dir / "DIAGNOSTIC_STATUS.json").write_text(
            json.dumps(status_payload, indent=2) + "\n", encoding="utf-8")

        summary = f"""# Frozen NVP/I2C digital trace summary

- Diagnostic magic: `0x{status['diag_magic']:08X}`
- Diagnostic flags: `0x{status['diag_flags']:08X}`
- Base functional commit: `{runtime_base}`
- Diagnostic patch SHA-256: `{runtime_patch}`
- Trigger reason: `{status['trigger_reason']}`
- Trigger index: `{status['trigger_index']}`
- Trace SHA-256: `{trace_sha}`
- ACK decision strobes captured: `{len(ack_indices)}`
- AXI-Lite reads: `{mmio.read_count}`
- AXI-Lite writes: `0`

At the trigger:

```text
SDA_STAGE1={trigger['sda_stage1']}
SDA_STAGE2={trigger['sda_stage2']}
SDA_FILTERED={trigger['sda_filtered']}
SCL_STAGE1={trigger['scl_stage1']}
SCL_STAGE2={trigger['scl_stage2']}
SCL_FILTERED={trigger['scl_filtered']}
SDA_DRIVE_LOW={trigger['sda_drive_low']}
SCL_DRIVE_LOW={trigger['scl_drive_low']}
ACK_VALUE_USED_BY_FSM={trigger['ack_value_used']}
BYTE_PHASE=0x{int(trigger['byte_phase']):02X}
OPERATION_INDEX=0x{int(trigger['operation_index']):02X}
CURRENT_TX_BYTE=0x{int(trigger['current_tx_byte']):02X}
```

```text
TRACE_TELEMETRY_CORRELATION={correlation}
PRIMARY_CLASSIFICATION={primary}
SECONDARY_OBSERVATIONS={','.join(secondary) if secondary else 'NONE'}
RAW_ANALOG_MEASUREMENT_AVAILABLE=NO
AXIL_WRITES=0
C2H_TRANSFERS=0
H2C_TRANSFERS=0
```
"""
        (args.output_dir / "TRACE_SUMMARY.md").write_text(summary, encoding="utf-8")
    finally:
        mmio.close()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"TRACE_DUMP_ERROR={exc}", file=sys.stderr)
        raise
