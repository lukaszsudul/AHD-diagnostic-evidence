# Operation Ledger

Initial state before source export:

```text
FORMAL_GIT_COMMITS=0
FORMAL_GIT_PUSHES=0
FORMAL_TAGS_CREATED=0
FORMAL_BRANCHES_CREATED=0
FORMAL_TRACKED_FILE_CHANGES=0
DIAGNOSTIC_LOCAL_BUILD_CYCLES=2
DIAGNOSTIC_SRAM_PROGRAM_ATTEMPTS=1
DIAGNOSTIC_SRAM_PROGRAM_SUCCESSES=1
FORMAL_RESTORE_PROGRAM_ATTEMPTS=0
FORMAL_RESTORE_PROGRAM_SUCCESSES=0
COLD_STARTS=0
UBUNTU_WARM_REBOOTS=1
AXIL_WRITES=0
PHASE3_STRESS_READS=0
C2H_TRANSFERS=0
H2C_TRANSFERS=0
PHASE3_RESUMED=NO
PHASE4_STARTED=NO
```

Build cycle 1 stopped during RTL elaboration before implementation or
bitstream generation because two observer-only VHDL-2008 constructs were not
accepted by the preserved project VHDL mode. The smallest observer-only syntax
correction was applied in the non-Git diagnostic export and the complete exact
sealed-R2 simulation gate passed before authorizing cycle 2.

Build cycle 2 completed synthesis, placement, full route, bitstream generation,
and all mandatory offline gates. No third build cycle was used.

The sealed diagnostic image was then programmed on its single authorized SRAM
attempt with EOS HIGH and DONE 1. The first required warm reboot completed,
the pinned XDMA driver was hash-gated and loaded, and the complete frozen trace
was retrieved once through 8,227 read-only diagnostic AXI-Lite transactions.
Two additional successful 46-word formal-map snapshots supplied bounded
post-trace NVP/video telemetry. No Phase-3 stress campaign occurred.

Formal restoration has not yet been attempted at this ledger checkpoint.
