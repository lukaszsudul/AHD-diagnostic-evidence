#!/usr/bin/env python3
"""Read-only dump/decoder for the ephemeral NVP Z8 midpoint experiment."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import socket
import stat
import struct
import subprocess
import sys


DIAG_BASE = 0x2000
TRACE_BASE = 0x3000
CONTEXT_BASE = 0xB000
SHADOW_BASE = 0xD000
EXPECTED_MAGIC = 0x4E565052
EXPECTED_SCHEMA = 0x00030000
EXPECTED_FLAGS = 0x00000007
EXPECTED_HOSTNAME = "VCDE-DUT-1"
EXPECTED_IP = "10.132.1.111"
EXPECTED_BDF = "0000:01:00.0"
EXPECTED_BASE_COMMIT = "fd32fcb65be3f1a59c569874195d1faeaf7d27e9"
EXPECTED_DRIVER_COMMIT = "8721136e74a66500b02d16cb41922d966139cd46"
DRIVER_REPOSITORY = Path("/home/vcdeagent1/FPGA_AHD_HOST/dma_ip_drivers")


STATUS_OFFSETS = {
    "diag_magic": 0x00, "schema_version": 0x04, "diag_flags": 0x08,
    "trace_status": 0x0C, "trace_trigger_reason": 0x10,
    "sample_clock_hz": 0x14, "trace_depth": 0x18,
    "trace_width_bits": 0x1C, "trace_pre_count": 0x20,
    "trace_post_count": 0x24, "trace_trigger_index": 0x28,
    "trace_final_write_index": 0x2C, "trace_overflow": 0x30,
    "base_commit_w0": 0x34, "base_commit_w1": 0x38,
    "base_commit_w2": 0x3C, "base_commit_w3": 0x40,
    "base_commit_w4": 0x44, "patch_sha_w0": 0x48,
    "patch_sha_w1": 0x4C, "patch_sha_w2": 0x50,
    "patch_sha_w3": 0x54, "patch_sha_w4": 0x58,
    "patch_sha_w5": 0x5C, "patch_sha_w6": 0x60,
    "patch_sha_w7": 0x64, "first_error_valid": 0x68,
    "first_error_phase": 0x6C, "first_error_step": 0x70,
    "first_error_meta_bank": 0x74, "first_error_phys_bank": 0x78,
    "first_error_register": 0x7C, "first_error_value": 0x80,
    "trace_valid_count": 0x84, "trace_physical_trigger_index": 0x88,
    "half_phase_cycles": 0x8C, "mid_high_offset_cycles": 0x90,
    "context_depth": 0x94, "context_width_bits": 0x98,
    "context_status": 0x9C, "context_trigger_reason": 0xA0,
    "context_valid_count": 0xA4, "context_final_write_index": 0xA8,
    "context_total_ticks": 0xAC, "shadow_depth": 0xB0,
    "shadow_width_bits": 0xB4, "shadow_status": 0xB8,
    "shadow_trigger_reason": 0xBC, "shadow_valid_count": 0xC0,
    "shadow_final_write_index": 0xC4, "shadow_total_events": 0xC8,
    "shadow_false_nack_count": 0xCC, "shadow_real_nack_count": 0xD0,
    "shadow_invalid_window_count": 0xD4,
    "context_base": 0xD8, "shadow_base": 0xDC,
}


TRACE_COLUMNS = [
    "sample_index", "relative_cycles_from_trigger", "relative_time_ns",
    "sda_stage1", "sda_stage2", "sda_filtered", "scl_stage1",
    "scl_stage2", "scl_filtered", "sda_drive_low", "scl_drive_low",
    "ack_decision_strobe", "ack_value_used", "first_nack_event",
    "first_nack_latched", "nvp_reset", "vdd1_enable", "vdd3_enable",
    "init_active", "bit_index", "byte_phase", "fsm_state",
    "operation_index", "current_tx_byte", "init_done", "init_error",
    "first_error_code", "first_error_valid", "raw_hex",
]

CONTEXT_COLUMNS = [
    "record_index", "global_tick_sequence", "state", "previous_state",
    "byte_phase", "bit_index", "operation_index", "slot_index",
    "init_phase", "preinit_action", "init_action", "meta_bank",
    "physical_bank", "physical_bank_valid", "is_read_operation",
    "sda_drive_low", "scl_drive_low", "sda_filtered", "scl_filtered",
    "ack_decision_strobe", "ack_value_used", "first_nack_event",
    "init_active", "init_done", "init_error", "pending_bank",
    "pending_register", "pending_data", "active_register",
    "active_write_data", "raw_hex",
]

SHADOW_COLUMNS = [
    "ack_event_index", "operation_index", "slot_index", "byte_phase",
    "tx_byte", "register", "write_value", "meta_bank", "physical_bank",
    "physical_bank_valid", "original_r1_ack_decision", "z8_consumed_ack",
    "z8_sample_invalid", "z8_sampled_scl",
    "functional_decision_sda", "functional_decision_scl",
    "functional_decision_sda_drive_low", "functional_decision_scl_drive_low",
    "first_nack_event", "scl_high_observed", "early_high_valid",
    "mid_high_valid", "late_high_valid", "sda_released_during_ack",
    "scl_released_during_ack", "half_phase_cycle_count_valid",
    "early_high_sda_stage1", "early_high_sda_stage2",
    "early_high_sda_filtered", "early_high_scl_stage1",
    "early_high_scl_stage2", "early_high_scl_filtered",
    "early_high_sda_drive_low", "early_high_scl_drive_low",
    "mid_high_sda_stage1", "mid_high_sda_stage2", "mid_high_sda_filtered",
    "mid_high_scl_stage1", "mid_high_scl_stage2", "mid_high_scl_filtered",
    "mid_high_sda_drive_low", "mid_high_scl_drive_low",
    "late_high_sda_stage1", "late_high_sda_stage2", "late_high_sda_filtered",
    "late_high_scl_stage1", "late_high_scl_stage2", "late_high_scl_filtered",
    "late_high_sda_drive_low", "late_high_scl_drive_low",
    "early_high_offset_cycles", "mid_high_offset_cycles",
    "late_high_offset_cycles", "measured_half_phase_cycles", "init_phase",
    "preinit_action", "init_action", "pending_bank", "pending_register",
    "pending_data", "first_error_code", "first_error_step",
    "first_error_meta_bank", "first_error_register", "first_error_value",
    "init_active", "init_done", "init_error", "no_scl_high",
    "shadow_correct_phase_ack", "classification", "raw_hex",
]


def fail(message: str) -> None:
    raise RuntimeError(message)


def field(word: int, lsb: int, width: int = 1) -> int:
    return (word >> lsb) & ((1 << width) - 1)


def write_csv(path: Path, rows: list[dict[str, object]], columns: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def read_text(path: Path) -> str:
    return path.read_text(encoding="ascii").strip().lower()


def check_platform(device: Path) -> dict[str, object]:
    if socket.gethostname() != EXPECTED_HOSTNAME:
        fail(f"wrong host: {socket.gethostname()} != {EXPECTED_HOSTNAME}")
    ip_output = subprocess.run(
        ["ip", "-4", "-o", "addr", "show"], check=True,
        text=True, capture_output=True).stdout
    if EXPECTED_IP not in ip_output:
        fail(f"expected host IPv4 {EXPECTED_IP} not present")

    matches: list[Path] = []
    for entry in Path("/sys/bus/pci/devices").iterdir():
        try:
            if read_text(entry / "vendor") == "0x10ee" and \
               read_text(entry / "device") == "0x7011":
                matches.append(entry)
        except (FileNotFoundError, PermissionError):
            continue
    if len(matches) != 1:
        fail(f"expected exactly one 10ee:7011 endpoint, found {len(matches)}")
    endpoint = matches[0]
    if endpoint.name != EXPECTED_BDF:
        fail(f"wrong BDF: {endpoint.name} != {EXPECTED_BDF}")
    expected = {
        "subsystem_vendor": "0x10ee", "subsystem_device": "0x0007",
        "class": "0x058000", "current_link_width": "1",
    }
    observed: dict[str, object] = {"bdf": endpoint.name}
    for name, value in expected.items():
        actual = read_text(endpoint / name)
        if actual != value:
            fail(f"{name} mismatch: {actual} != {value}")
        observed[name] = actual
    speed = (endpoint / "current_link_speed").read_text().strip()
    if not speed.startswith("2.5 GT/s"):
        fail(f"link is not Gen1: {speed}")
    observed["current_link_speed"] = speed

    resource_lines = (endpoint / "resource").read_text().splitlines()
    sizes: list[int] = []
    for line in resource_lines[:2]:
        start_s, end_s, _flags_s = line.split()
        start, end = int(start_s, 16), int(end_s, 16)
        sizes.append(0 if start == 0 and end == 0 else end - start + 1)
    if sizes != [0x20000, 0x10000]:
        fail(f"BAR sizes mismatch: {sizes}")
    observed["bar0_bytes"], observed["bar1_bytes"] = sizes

    if not Path("/sys/module/xdma").is_dir():
        fail("xdma kernel module is not loaded")
    driver_commit = subprocess.run(
        ["git", "-C", str(DRIVER_REPOSITORY), "rev-parse", "HEAD"],
        check=True, text=True, capture_output=True).stdout.strip().lower()
    if driver_commit != EXPECTED_DRIVER_COMMIT:
        fail(f"XDMA driver commit mismatch: {driver_commit}")
    observed["driver_commit"] = driver_commit
    st = device.stat()
    if not stat.S_ISCHR(st.st_mode):
        fail(f"user endpoint is not a character device: {device}")
    observed["device"] = str(device)
    return observed


class ReadOnlyMmio:
    def __init__(self, device: Path) -> None:
        self.fd = os.open(device, os.O_RDONLY | os.O_CLOEXEC)
        self.read_count = 0

    def close(self) -> None:
        os.close(self.fd)

    def read32(self, offset: int) -> int:
        payload = os.pread(self.fd, 4, offset)
        if len(payload) != 4:
            fail(f"short AXI-Lite read at 0x{offset:05x}: {len(payload)}")
        self.read_count += 1
        return struct.unpack("<I", payload)[0]


def decode_trace(index: int, trigger: int, clock_hz: int, word: int) -> dict[str, object]:
    relative = index - trigger
    return {
        "sample_index": index,
        "relative_cycles_from_trigger": relative,
        "relative_time_ns": relative * 1_000_000_000 // clock_hz,
        "sda_stage1": field(word, 0), "sda_stage2": field(word, 1),
        "sda_filtered": field(word, 2), "scl_stage1": field(word, 3),
        "scl_stage2": field(word, 4), "scl_filtered": field(word, 5),
        "sda_drive_low": field(word, 6), "scl_drive_low": field(word, 7),
        "ack_decision_strobe": field(word, 8), "ack_value_used": field(word, 9),
        "first_nack_event": field(word, 10), "first_nack_latched": field(word, 11),
        "nvp_reset": field(word, 12), "vdd1_enable": field(word, 13),
        "vdd3_enable": field(word, 14), "init_active": field(word, 15),
        "bit_index": field(word, 16, 4), "byte_phase": field(word, 20, 8),
        "fsm_state": field(word, 28, 8), "operation_index": field(word, 36, 8),
        "current_tx_byte": field(word, 44, 8), "init_done": field(word, 52),
        "init_error": field(word, 53), "first_error_code": field(word, 54, 8),
        "first_error_valid": field(word, 62), "raw_hex": f"0x{word:016X}",
    }


def decode_context(index: int, previous_state: int | None, word: int) -> dict[str, object]:
    return {
        "record_index": index, "global_tick_sequence": field(word, 0, 16),
        "state": field(word, 16, 8),
        "previous_state": "" if previous_state is None else previous_state,
        "byte_phase": field(word, 24, 8), "bit_index": field(word, 32, 4),
        "operation_index": field(word, 36, 8), "slot_index": field(word, 44, 8),
        "init_phase": field(word, 52, 4), "preinit_action": field(word, 56, 2),
        "init_action": field(word, 58, 2), "meta_bank": field(word, 60, 8),
        "physical_bank": field(word, 68, 8), "physical_bank_valid": field(word, 76),
        "is_read_operation": field(word, 77), "sda_drive_low": field(word, 78),
        "scl_drive_low": field(word, 79), "sda_filtered": field(word, 80),
        "scl_filtered": field(word, 81), "ack_decision_strobe": field(word, 82),
        "ack_value_used": field(word, 83), "first_nack_event": field(word, 84),
        "init_active": field(word, 85), "init_done": field(word, 86),
        "init_error": field(word, 87), "pending_bank": field(word, 88, 8),
        "pending_register": field(word, 96, 8), "pending_data": field(word, 104, 8),
        "active_register": field(word, 112, 8), "active_write_data": field(word, 120, 8),
        "raw_hex": f"0x{word:032X}",
    }


def decode_shadow(word: int) -> dict[str, object]:
    mid_valid = field(word, 89)
    mid_filtered = field(word, 106)
    z8_ack = field(word, 81)
    z8_invalid = field(word, 95)
    if not mid_valid or z8_invalid:
        shadow_ack, classification = "INVALID_NO_SCL_HIGH", "INVALID_ACK_WINDOW"
    elif mid_filtered == 0:
        shadow_ack, classification = "ACK_LOW", "Z8_FALSE_NACK_UNEXPECTED" if z8_ack == 0 else "Z8_ACK_MATCH"
    else:
        shadow_ack, classification = "NACK_HIGH", "REAL_DIGITAL_NACK" if z8_ack == 0 else "Z8_ACK_DECISION_MISMATCH"
    return {
        "ack_event_index": field(word, 0, 16), "operation_index": field(word, 16, 8),
        "slot_index": field(word, 24, 8), "byte_phase": field(word, 32, 8),
        "tx_byte": field(word, 40, 8), "register": field(word, 48, 8),
        "write_value": field(word, 56, 8), "meta_bank": field(word, 64, 8),
        "physical_bank": field(word, 72, 8), "physical_bank_valid": field(word, 80),
        "original_r1_ack_decision": "ACK_LOW" if field(word, 94) else "NACK_HIGH",
        "z8_consumed_ack": "ACK_LOW" if z8_ack else "NACK_HIGH",
        "z8_sample_invalid": z8_invalid, "z8_sampled_scl": field(word, 255),
        "functional_decision_sda": field(word, 82), "functional_decision_scl": field(word, 83),
        "functional_decision_sda_drive_low": field(word, 84),
        "functional_decision_scl_drive_low": field(word, 85),
        "first_nack_event": field(word, 86), "scl_high_observed": field(word, 87),
        "early_high_valid": field(word, 88), "mid_high_valid": mid_valid,
        "late_high_valid": field(word, 90), "sda_released_during_ack": field(word, 91),
        "scl_released_during_ack": field(word, 92),
        "half_phase_cycle_count_valid": field(word, 93),
        "early_high_sda_stage1": field(word, 96), "early_high_sda_stage2": field(word, 97),
        "early_high_sda_filtered": field(word, 98), "early_high_scl_stage1": field(word, 99),
        "early_high_scl_stage2": field(word, 100), "early_high_scl_filtered": field(word, 101),
        "early_high_sda_drive_low": field(word, 102), "early_high_scl_drive_low": field(word, 103),
        "mid_high_sda_stage1": field(word, 104), "mid_high_sda_stage2": field(word, 105),
        "mid_high_sda_filtered": mid_filtered, "mid_high_scl_stage1": field(word, 107),
        "mid_high_scl_stage2": field(word, 108), "mid_high_scl_filtered": field(word, 109),
        "mid_high_sda_drive_low": field(word, 110), "mid_high_scl_drive_low": field(word, 111),
        "late_high_sda_stage1": field(word, 112), "late_high_sda_stage2": field(word, 113),
        "late_high_sda_filtered": field(word, 114), "late_high_scl_stage1": field(word, 115),
        "late_high_scl_stage2": field(word, 116), "late_high_scl_filtered": field(word, 117),
        "late_high_sda_drive_low": field(word, 118), "late_high_scl_drive_low": field(word, 119),
        "early_high_offset_cycles": field(word, 120, 10),
        "mid_high_offset_cycles": field(word, 130, 10),
        "late_high_offset_cycles": field(word, 140, 10),
        "measured_half_phase_cycles": field(word, 150, 10),
        "init_phase": field(word, 160, 8), "preinit_action": field(word, 168, 8),
        "init_action": field(word, 176, 8), "pending_bank": field(word, 184, 8),
        "pending_register": field(word, 192, 8), "pending_data": field(word, 200, 8),
        "first_error_code": field(word, 208, 8), "first_error_step": field(word, 216, 8),
        "first_error_meta_bank": field(word, 224, 8),
        "first_error_register": field(word, 232, 8), "first_error_value": field(word, 240, 8),
        "init_active": field(word, 248), "init_done": field(word, 249),
        "init_error": field(word, 250), "no_scl_high": field(word, 251),
        "shadow_correct_phase_ack": shadow_ack, "classification": classification,
        "raw_hex": f"0x{word:064X}",
    }


def classify(status: dict[str, int], events: list[dict[str, object]]) -> tuple[str, int, int, int]:
    if status["shadow_trigger_reason"] == 2 and status["first_error_valid"] == 0:
        return "Z8_NO_NACK_INITIALIZATION_REQUIRES_VIDEO_BASELINE", 0, 0, 0
    first = [row for row in events if int(row["first_nack_event"]) == 1]
    if len(first) != 1:
        return "INCONCLUSIVE_Z8_TRACE", 0, 0, 0
    false_count = sum(row["classification"] == "Z8_FALSE_NACK_UNEXPECTED" for row in events)
    real_count = sum(row["classification"] == "REAL_DIGITAL_NACK" for row in events)
    invalid_count = sum(row["classification"] == "INVALID_ACK_WINDOW" for row in events)
    if false_count and real_count:
        primary = "INCONCLUSIVE_Z8_MIXED_FUNCTIONAL_SHADOW_RESULT"
    elif false_count:
        primary = "INCONCLUSIVE_Z8_FUNCTIONAL_SHADOW_MISMATCH"
    elif real_count:
        primary = "Z8_INSUFFICIENT_REAL_DIGITAL_NACK_REMAINS"
    elif invalid_count:
        primary = "Z8_ACK_SAMPLE_INVALID_SCL_NOT_HIGH"
    else:
        primary = "INCONCLUSIVE_Z8_TRACE"
    return primary, false_count, real_count, invalid_count


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", type=Path, default=Path("/dev/xdma0_user"))
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--expected-patch-sha", required=True)
    parser.add_argument("--expected-base-commit", default=EXPECTED_BASE_COMMIT)
    args = parser.parse_args()
    expected_patch = args.expected_patch_sha.lower()
    expected_base = args.expected_base_commit.lower()
    if len(expected_patch) != 64 or any(c not in "0123456789abcdef" for c in expected_patch):
        fail("--expected-patch-sha must be 64 hexadecimal characters")
    if len(expected_base) != 40 or any(c not in "0123456789abcdef" for c in expected_base):
        fail("--expected-base-commit must be 40 hexadecimal characters")

    args.output_dir.mkdir(parents=True, exist_ok=False)
    platform = check_platform(args.device)
    mmio = ReadOnlyMmio(args.device)
    try:
        status = {name: mmio.read32(DIAG_BASE + offset) for name, offset in STATUS_OFFSETS.items()}
        if status["diag_magic"] != EXPECTED_MAGIC or status["schema_version"] != EXPECTED_SCHEMA:
            fail("Z8 diagnostic identity mismatch")
        if status["diag_flags"] != EXPECTED_FLAGS:
            fail(f"diagnostic flags mismatch: 0x{status['diag_flags']:08X}")
        if not status["trace_status"] & 0x4 or not status["trace_status"] & 0x8 or status["trace_status"] & 0x10:
            fail("high-resolution trace is not frozen/full/clean")
        if not status["context_status"] & 0x4 or status["context_status"] & 0x10:
            fail("context ring is not frozen/clean")
        if not status["shadow_status"] & 0x4 or status["shadow_status"] & 0x10:
            fail("shadow event ring is not frozen/clean")
        expected_geometry = {
            "sample_clock_hz": 62_500_000, "trace_depth": 4096,
            "trace_width_bits": 64, "trace_pre_count": 3072,
            "trace_post_count": 1024, "trace_trigger_index": 3072,
            "trace_valid_count": 4096, "half_phase_cycles": 626,
            "mid_high_offset_cycles": 313, "context_depth": 512,
            "context_width_bits": 128, "shadow_depth": 256,
            "shadow_width_bits": 256, "context_base": CONTEXT_BASE,
            "shadow_base": SHADOW_BASE,
        }
        for key, value in expected_geometry.items():
            if status[key] != value:
                fail(f"{key} mismatch: {status[key]} != {value}")
        if not 0 < status["context_valid_count"] <= status["context_depth"]:
            fail("invalid context record count")
        if not 0 < status["shadow_valid_count"] <= status["shadow_depth"]:
            fail("invalid shadow event count")

        runtime_base = "".join(f"{status[f'base_commit_w{i}']:08x}" for i in range(5))
        runtime_patch = "".join(f"{status[f'patch_sha_w{i}']:08x}" for i in range(8))
        if runtime_base != expected_base:
            fail(f"base commit mismatch: {runtime_base}")
        if runtime_patch != expected_patch:
            fail(f"patch SHA mismatch: {runtime_patch}")

        trace_words: list[int] = []
        trace_rows: list[dict[str, object]] = []
        trace_raw = bytearray()
        for index in range(status["trace_depth"]):
            lo = mmio.read32(TRACE_BASE + index * 8)
            hi = mmio.read32(TRACE_BASE + index * 8 + 4)
            word = lo | hi << 32
            trace_words.append(word)
            trace_raw.extend(struct.pack("<Q", word))
            trace_rows.append(decode_trace(index, status["trace_trigger_index"],
                                           status["sample_clock_hz"], word))

        context_words: list[int] = []
        context_rows: list[dict[str, object]] = []
        context_raw = bytearray()
        previous_state: int | None = None
        for index in range(status["context_valid_count"]):
            words = [mmio.read32(CONTEXT_BASE + index * 16 + w * 4) for w in range(4)]
            word = sum(part << (32 * w) for w, part in enumerate(words))
            context_words.append(word)
            context_raw.extend(struct.pack("<4I", *words))
            row = decode_context(index, previous_state, word)
            previous_state = int(row["state"])
            context_rows.append(row)

        shadow_words: list[int] = []
        shadow_rows: list[dict[str, object]] = []
        shadow_raw = bytearray()
        for index in range(status["shadow_valid_count"]):
            words = [mmio.read32(SHADOW_BASE + index * 32 + w * 4) for w in range(8)]
            word = sum(part << (32 * w) for w, part in enumerate(words))
            shadow_words.append(word)
            shadow_raw.extend(struct.pack("<8I", *words))
            shadow_rows.append(decode_shadow(word))

        primary, false_count, real_count, invalid_count = classify(status, shadow_rows)
        if false_count != status["shadow_false_nack_count"] or \
           real_count != status["shadow_real_nack_count"] or \
           invalid_count != status["shadow_invalid_window_count"]:
            fail("decoded first-NACK classification counters disagree with hardware")

        (args.output_dir / "TRACE_RAW.bin").write_bytes(trace_raw)
        (args.output_dir / "FSM_TICK_CONTEXT_RAW.bin").write_bytes(context_raw)
        (args.output_dir / "SHADOW_ACK_EVENTS_RAW.bin").write_bytes(shadow_raw)
        write_csv(args.output_dir / "TRACE_DECODED.csv", trace_rows, TRACE_COLUMNS)
        write_csv(args.output_dir / "FSM_TICK_CONTEXT.csv", context_rows, CONTEXT_COLUMNS)
        write_csv(args.output_dir / "SHADOW_ACK_EVENTS.csv", shadow_rows, SHADOW_COLUMNS)
        focused = [row for row in trace_rows
                   if abs(int(row["relative_cycles_from_trigger"])) <= 1024]
        write_csv(args.output_dir / "ACK_DECISION_FOCUSED_Z8.csv", focused, TRACE_COLUMNS)

        hashes = {}
        for name in ("TRACE_RAW.bin", "FSM_TICK_CONTEXT_RAW.bin", "SHADOW_ACK_EVENTS_RAW.bin"):
            digest = hashlib.sha256((args.output_dir / name).read_bytes()).hexdigest().upper()
            hashes[name] = digest
        (args.output_dir / "Z8_RAW_SHA256.txt").write_text(
            "".join(f"{digest}  {name}\n" for name, digest in hashes.items()), encoding="ascii")

        first_nack = next((row for row in shadow_rows if int(row["first_nack_event"]) == 1), None)
        correlation = "INCONCLUSIVE"
        if first_nack is not None and \
           int(first_nack["byte_phase"]) == status["first_error_phase"] and \
           int(first_nack["operation_index"]) == status["first_error_step"]:
            correlation = "PASS"
        elif status["shadow_trigger_reason"] == 2 and not status["first_error_valid"]:
            correlation = "NOT_APPLICABLE_NO_NACK"

        payload = {
            "platform": platform,
            "status": {key: f"0x{value:08X}" for key, value in status.items()},
            "runtime_base_commit": runtime_base,
            "runtime_patch_sha256": runtime_patch,
            "mmio_reads": mmio.read_count, "mmio_writes": 0,
            "raw_sha256": hashes, "primary_classification": primary,
            "false_nack_count": false_count, "real_digital_nack_count": real_count,
            "invalid_ack_windows": invalid_count,
            "trace_telemetry_correlation": correlation,
        }
        (args.output_dir / "Z8_DIAGNOSTIC_STATUS.json").write_text(
            json.dumps(payload, indent=2) + "\n", encoding="utf-8")

        first_text = "NONE" if first_nack is None else json.dumps(first_nack, indent=2)
        summary = f"""# NVP Z8 midpoint ACK experiment summary

- Base functional commit: `{runtime_base}`
- Combined R2+Z8 experiment patch SHA-256: `{runtime_patch}`
- Half-phase: `{status['half_phase_cycles']}` clocks / `{status['half_phase_cycles'] * 16}` ns
- Mid-high sample: cycle `{status['mid_high_offset_cycles']}`
- FSM-tick context records: `{status['context_valid_count']}`
- Shadow ACK event records: `{status['shadow_valid_count']}`
- AXI-Lite reads: `{mmio.read_count}`
- AXI-Lite writes: `0`

First functional NACK event:

```json
{first_text}
```

```text
Z8_FALSE_NACK_COUNT={false_count}
Z8_REAL_DIGITAL_NACK_COUNT={real_count}
Z8_INVALID_ACK_WINDOWS={invalid_count}
TRACE_TELEMETRY_CORRELATION={correlation}
Z8_PRIMARY_CLASSIFICATION={primary}
RAW_ANALOG_MEASUREMENT_AVAILABLE=NO
AXIL_WRITES=0
C2H_TRANSFERS=0
H2C_TRANSFERS=0
```
"""
        (args.output_dir / "Z8_TRACE_SUMMARY.md").write_text(summary, encoding="utf-8")
    finally:
        mmio.close()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"Z8_TRACE_DUMP_ERROR={exc}", file=sys.stderr)
        raise
